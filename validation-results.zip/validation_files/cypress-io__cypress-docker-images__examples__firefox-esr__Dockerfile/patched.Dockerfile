FROM cypress/base@sha256:da5bab4c14ab67578ac7539603de2430d50240f29f7827dda7140e4e4bf6d023
COPY . /opt/app
WORKDIR /opt/app
# TODO(flakiscan): could not automatically fix: DL3009
RUN apt-get update                 # Update package index
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends firefox-esr -y # Install Firefox ESR && rm -rf /var/lib/apt/lists/*
RUN npx cypress install            # Install Cypress binary
