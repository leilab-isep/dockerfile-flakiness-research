FROM cypress/browsers@sha256:4e487953a62c66c9b0ba84e07ecc84089612e213718b2a76c13c98ca66f97bae
COPY . /opt/app
WORKDIR /opt/app
RUN npx cypress install # Install Cypress binary into image
