#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM mcr.microsoft.com/windows/servercore:ltsc2022

# $ProgressPreference: https://github.com/PowerShell/PowerShell/issues/2138#issuecomment-251261324
SHELL ["powershell", "-Command", "$ErrorActionPreference = 'Stop'; $ProgressPreference = 'SilentlyContinue';"]

# enable TLS 1.2
# https://docs.microsoft.com/en-us/system-center/vmm/install-tls?view=sc-vmm-1801
# https://docs.microsoft.com/en-us/windows-server/identity/ad-fs/operations/manage-ssl-protocols-in-ad-fs#enable-tls-12
RUN Write-Host 'Enabling TLS 1.2 (https://githubengineering.com/crypto-removal-notice/) ...'; \
	$tls12RegBase = 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2'; \
	if (Test-Path $tls12RegBase) { throw ('"{0}" already exists!' -f $tls12RegBase) }; \
	New-Item -Path ('{0}/Client' -f $tls12RegBase) -Force; \
	New-Item -Path ('{0}/Server' -f $tls12RegBase) -Force; \
	New-ItemProperty -Path ('{0}/Client' -f $tls12RegBase) -Name 'DisabledByDefault' -PropertyType DWORD -Value 0 -Force; \
	New-ItemProperty -Path ('{0}/Client' -f $tls12RegBase) -Name 'Enabled' -PropertyType DWORD -Value 1 -Force; \
	New-ItemProperty -Path ('{0}/Server' -f $tls12RegBase) -Name 'DisabledByDefault' -PropertyType DWORD -Value 0 -Force; \
	New-ItemProperty -Path ('{0}/Server' -f $tls12RegBase) -Name 'Enabled' -PropertyType DWORD -Value 1 -Force; \
	Write-Host 'Complete.'

ENV JAVA_HOME C:\\openjdk-27
RUN $newPath = ('{0}\bin;{1}' -f $env:JAVA_HOME, $env:PATH); \
	Write-Host ('Updating PATH: {0}' -f $newPath); \
	setx /M PATH $newPath; \
	Write-Host 'Complete.'

# https://jdk.java.net/
# >
# > Java Development Kit builds, from Oracle
# >
ENV JAVA_VERSION 27
ENV JAVA_URL https://download.java.net/java/GA/jdk27/55ce5470a6294008af0057ff4626d0e5/35/GPL/openjdk-27_windows-x64_bin.zip
ENV JAVA_SHA256 41172837168dd25a8d9fe5eb253ac1efc568c5f9ff608144bcacadfdf50f876c

RUN ["/bin/bash", "-o", "pipefail", "-c", "Write-Host ('Downloading {0} ...' -f $env:JAVA_URL); \\\n\t[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; \\\n\tInvoke-WebRequest -Uri $env:JAVA_URL -OutFile 'openjdk.zip'; \\\n\tWrite-Host ('Verifying sha256 ({0}) ...' -f $env:JAVA_SHA256); \\\n\tif ((Get-FileHash openjdk.zip -Algorithm sha256).Hash -ne $env:JAVA_SHA256) { \\\n\t\tWrite-Host 'FAILED!'; \\\n\t\texit 1; \\\n\t}; \\\n\t\\\n\tWrite-Host 'Expanding ...'; \\\n\tNew-Item -ItemType Directory -Path C:\\temp | Out-Null; \\\n\tExpand-Archive openjdk.zip -DestinationPath C:\\temp; \\\n\tMove-Item -Path C:\\temp\\* -Destination $env:JAVA_HOME; \\\n\tRemove-Item C:\\temp; \\\n\t\\\n\tWrite-Host 'Removing ...'; \\\n\tRemove-Item openjdk.zip -Force; \\\n\t\\\n\tWrite-Host 'Verifying install ...'; \\\n\tWrite-Host '  javac --version'; javac --version; \\\n\tWrite-Host '  java --version'; java --version; \\\n\t\\\n\tWrite-Host 'Complete.'"]

# "jshell" is an interactive REPL for Java (see https://en.wikipedia.org/wiki/JShell)
CMD ["jshell"]
