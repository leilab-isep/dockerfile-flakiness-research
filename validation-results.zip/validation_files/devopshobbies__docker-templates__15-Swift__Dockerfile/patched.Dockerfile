# Build stage
FROM swift@sha256:56ef1be2c1ca36f4c52440357dc1fcdfdb5e113587134fcadeef57c225c71b54 as builder
COPY app.swift .
RUN swiftc app.swift -o app
# Run stage
FROM swift:slim AS runner
COPY --from=builder /app .
CMD ["./app"]
