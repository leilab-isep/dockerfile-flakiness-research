FROM cypress/base@sha256:da5bab4c14ab67578ac7539603de2430d50240f29f7827dda7140e4e4bf6d023
COPY . /opt/app
WORKDIR /opt/app
# Install Cypress binary
RUN npx cypress install
# Install Chrome for Testing
ARG CHROME_VERSION=stable
RUN ["/bin/bash", "-o", "pipefail", "-c", "INSTALL_OUTPUT=$(npx @puppeteer/browsers install chrome@${CHROME_VERSION} --path /tmp/chrome-for-testing) && \\\nDOWNLOAD_DIR=$(echo \"$INSTALL_OUTPUT\" | grep -o '\\/.*\\/chrome-linux64') && \\\nmv $DOWNLOAD_DIR /opt/chrome-for-testing"]
# TODO(flakiscan): could not automatically fix: DL3009
RUN apt-get update && \
    while read -r pkg; do \
        apt-get satisfy -y --no-install-recommends "$pkg"; \
    done < /opt/chrome-for-testing/deb.deps
RUN ln -fs /opt/chrome-for-testing/chrome /usr/local/bin/chrome
RUN rm -rf /tmp/chrome-for-testing
