ARG BASE_TEST_IMAGE='cypress/factory'

# TODO(flakiscan): could not automatically fix: implicit_latest
FROM ${BASE_TEST_IMAGE}
RUN echo "current user: $(whoami)"
ENV CI=1
COPY . /opt/app
WORKDIR /opt/app
RUN npm install cypress@16.0.0 --save-dev --ignore-scripts && npm cache clean --force
RUN npx cypress install
RUN npx cypress verify
