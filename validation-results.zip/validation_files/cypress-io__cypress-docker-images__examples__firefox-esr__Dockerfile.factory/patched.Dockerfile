FROM cypress/factory@sha256:c717211343e3e21e8852dce9ca9f52377ce179ec16e01d8acbcd6fdd457c4bee
COPY . /opt/app
WORKDIR /opt/app
# TODO(flakiscan): could not automatically fix: DL3009
RUN apt-get update                 # Update package index
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends firefox-esr -y # Install Firefox ESR && rm -rf /var/lib/apt/lists/*
RUN npx cypress install            # Install Cypress binary
