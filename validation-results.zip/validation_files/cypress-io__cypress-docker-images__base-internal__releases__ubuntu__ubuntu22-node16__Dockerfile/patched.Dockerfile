# TODO(flakiscan): could not automatically fix: ruleMoreThanOneInstall
FROM ubuntu:22.04

# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && \
  apt-get install --no-install-recommends -y apt-transport-https curl && rm -rf /var/lib/apt/lists/*

RUN curl -f -sL https://deb.nodesource.com/setup_16.x -o nodesource_setup.sh && echo '60fd3d2fce9277b265862af85f9fe3d835935b10cd71ea5e0d68d3506967f9e2  nodesource_setup.sh' > nodesource_setup.sh.sha256 && sha256sum -c nodesource_setup.sh.sha256
RUN bash nodesource_setup.sh
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y nodejs && rm -rf /var/lib/apt/lists/*

# Install latest NPM and Yarn
RUN npm install -g npm@latest && npm cache clean --force
RUN npm install -g yarn@latest && npm cache clean --force

# install additional native dependencies build tools
# TODO(flakiscan): could not automatically fix: aptGetInstallThenRemoveAptLists, aptGetInstallUseNoRec, aptGetUpdatePrecedesInstall
RUN apt install -y build-essential

# install Git client
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y git && rm -rf /var/lib/apt/lists/*
# install unzip utility to speed up Cypress unzips
# https://github.com/cypress-io/cypress/releases/tag/v3.8.0
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y unzip && rm -rf /var/lib/apt/lists/*

# avoid any prompts
ENV DEBIAN_FRONTEND noninteractive
# install tzdata package
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y tzdata && rm -rf /var/lib/apt/lists/*
# set your timezone
RUN ln -fs /usr/share/zoneinfo/America/New_York /etc/localtime
RUN dpkg-reconfigure --frontend noninteractive tzdata

# install Cypress dependencies (separate commands to avoid time outs)
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y \
    libatk1.0-0 \
    libgtk2.0-0 \
    libglib2.0-0 \
    libatk-bridge2.0-0 \
    libcups2 \
    libgtk-3-0 \
    libgbm1 && rm -rf /var/lib/apt/lists/*
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y \
    libnotify-dev && rm -rf /var/lib/apt/lists/*
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y \
    libgconf-2-4 \
    libnss3 \
    libxss1 && rm -rf /var/lib/apt/lists/*
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y \
    libasound2 \
    xvfb && rm -rf /var/lib/apt/lists/*

# a few environment variables to make NPM installs easier
# good colors for most applications
ENV TERM xterm
# avoid million NPM install messages
ENV npm_config_loglevel warn
# allow installing when the main user is root
ENV npm_config_unsafe_perm true

# versions of local tools
RUN echo  " node version:    $(node -v) \n" \
  "npm version:     $(npm -v) \n" \
  "yarn version:    $(yarn -v) \n" \
  "debian version:  $(cat /etc/debian_version) \n" \
  "user:            $(whoami) \n" \
  "git:             $(git --version) \n"

RUN echo "More version info"
RUN cat /etc/lsb-release
RUN cat /etc/os-release
