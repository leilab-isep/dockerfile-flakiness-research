#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM debian:trixie-slim

# explicitly set user/group IDs
RUN set -eux; \
	groupadd -r postgres --gid=999; \
# https://salsa.debian.org/postgresql/postgresql-common/blob/997d842ee744687d99a2b2d95c1083a2615c79e8/debian/postgresql-common.postinst#L32-35
	useradd -r -g postgres --uid=999 --home-dir=/var/lib/postgresql --shell=/bin/bash postgres; \
# also create the postgres user's home directory with appropriate permissions
# see https://github.com/docker-library/postgres/issues/274
	install --verbose --directory --owner postgres --group postgres --mode 1777 /var/lib/postgresql

# TODO(flakiscan): could not automatically fix: DL3008
RUN set -ex; \
	apt-get update; \
	apt-get install -y --no-install-recommends \
		gnupg \
# https://www.postgresql.org/docs/16/app-psql.html#APP-PSQL-META-COMMAND-PSET-PAGER
# https://github.com/postgres/postgres/blob/REL_16_1/src/include/fe_utils/print.h#L25
# (if "less" is available, it gets used as the default pager for psql, and it only adds ~1.5MiB to our image size)
		less \
	; \
	rm -rf /var/lib/apt/lists/*

# grab gosu for easy step-down from root
# https://github.com/tianon/gosu/releases
ENV GOSU_VERSION 1.19
# TODO(flakiscan): could not automatically fix: DL3008, download_no_checksum
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tsavedAptMark=\"$(apt-mark showmanual)\"; \\\n\tapt-get update; \\\n\tapt-get install -y --no-install-recommends ca-certificates wget; \\\n\trm -rf /var/lib/apt/lists/*; \\\n\tdpkgArch=\"$(dpkg --print-architecture | awk -F- '{ print $NF }')\"; \\\n\twget -O /usr/local/bin/gosu \"https://github.com/tianon/gosu/releases/download/$GOSU_VERSION/gosu-$dpkgArch\"; \\\n\twget -O /usr/local/bin/gosu.asc \"https://github.com/tianon/gosu/releases/download/$GOSU_VERSION/gosu-$dpkgArch.asc\"; \\\n\texport GNUPGHOME=\"$(mktemp -d)\"; \\\n\tgpg --batch --keyserver hkps://keys.openpgp.org --recv-keys B42F6819007F00F88E364FD4036A9C25BF357DD4; \\\n\tgpg --batch --verify /usr/local/bin/gosu.asc /usr/local/bin/gosu; \\\n\tgpgconf --kill all; \\\n\trm -rf \"$GNUPGHOME\" /usr/local/bin/gosu.asc; \\\n\tapt-mark auto '.*' > /dev/null; \\\n\t[ -z \"$savedAptMark\" ] || apt-mark manual $savedAptMark > /dev/null; \\\n\tapt-get purge -y --auto-remove -o APT::AutoRemove::RecommendsImportant=false; \\\n\tchmod +x /usr/local/bin/gosu; \\\n\tgosu --version; \\\n\tgosu nobody true"]

# make the "en_US.UTF-8" locale so postgres will be utf-8 enabled by default
# TODO(flakiscan): could not automatically fix: DL3008
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tif [ -f /etc/dpkg/dpkg.cfg.d/docker ]; then \\\n\t\tgrep -q '/usr/share/locale' /etc/dpkg/dpkg.cfg.d/docker; \\\n\t\tsed -ri '/\\/usr\\/share\\/locale/d' /etc/dpkg/dpkg.cfg.d/docker; \\\n\t\t! grep -q '/usr/share/locale' /etc/dpkg/dpkg.cfg.d/docker; \\\n\tfi; \\\n\tapt-get update; apt-get install -y --no-install-recommends locales; rm -rf /var/lib/apt/lists/*; \\\n\techo 'en_US.UTF-8 UTF-8' >> /etc/locale.gen; \\\n\tlocale-gen; \\\n\tlocale -a | grep 'en_US.utf8'"]
ENV LANG en_US.utf8

# TODO(flakiscan): could not automatically fix: DL3008
RUN set -eux; \
	apt-get update; \
	apt-get install -y --no-install-recommends \
		libnss-wrapper \
		xz-utils \
		zstd \
	; \
	rm -rf /var/lib/apt/lists/*

RUN mkdir /docker-entrypoint-initdb.d

RUN set -ex; \
# pub   4096R/ACCC4CF8 2011-10-13 [expires: 2019-07-02]
#       Key fingerprint = B97B 0AFC AA1A 47F0 44F2  44A0 7FCC 7D46 ACCC 4CF8
# uid                  PostgreSQL Debian Repository
	key='B97B0AFCAA1A47F044F244A07FCC7D46ACCC4CF8'; \
	export GNUPGHOME="$(mktemp -d)"; \
	mkdir -p /usr/local/share/keyrings/; \
	gpg --batch --keyserver keyserver.ubuntu.com --recv-keys "$key"; \
	gpg --batch --export --armor "$key" > /usr/local/share/keyrings/postgres.gpg.asc; \
	gpgconf --kill all; \
	rm -rf "$GNUPGHOME"

ENV PG_MAJOR 17
ENV PATH $PATH:/usr/lib/postgresql/$PG_MAJOR/bin

ENV PG_VERSION 17.11-1.pgdg13+2

# TODO(flakiscan): could not automatically fix: DL3008, ruleMoreThanOneInstall
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -ex; \\\n\t\\\n\texport PYTHONDONTWRITEBYTECODE=1; \\\n\t\\\n\tdpkgArch=\"$(dpkg --print-architecture)\"; \\\n\taptRepo=\"[ signed-by=/usr/local/share/keyrings/postgres.gpg.asc ] http://apt.postgresql.org/pub/repos/apt trixie-pgdg main $PG_MAJOR\"; \\\n\tcase \"$dpkgArch\" in \\\n\t\tamd64 | arm64 | loong64 | ppc64el) \\\n\t\t\techo \"deb $aptRepo\" > /etc/apt/sources.list.d/pgdg.list; \\\n\t\t\tapt-get update; \\\n\t\t\t;; \\\n\t\t*) \\\n\t\t\techo \"deb-src $aptRepo\" > /etc/apt/sources.list.d/pgdg.list; \\\n\t\t\t\\\n\t\t\tsavedAptMark=\"$(apt-mark showmanual)\"; \\\n\t\t\t\\\n\t\t\ttempDir=\"$(mktemp -d)\"; \\\n\t\t\tcd \"$tempDir\"; \\\n\t\t\t\\\n\t\t\tapt-get update; \\\n\t\t\tapt-get install -y --no-install-recommends dpkg-dev; \\\n\t\t\techo \"deb [ trusted=yes ] file://$tempDir ./\" > /etc/apt/sources.list.d/temp.list; \\\n\t\t\t_update_repo() { \\\n\t\t\t\tdpkg-scanpackages . > Packages; \\\n\t\t\t\tapt-get -o Acquire::GzipIndexes=false update; \\\n\t\t\t}; \\\n\t\t\t_update_repo; \\\n\t\t\t\\\n\t\t\tnproc=\"$(nproc)\"; \\\n\t\t\texport DEB_BUILD_OPTIONS=\"nocheck parallel=$nproc\"; \\\n\t\t\tapt-get build-dep -y postgresql-common-dev; \\\n\t\t\tapt-get source --compile postgresql-common-dev; \\\n\t\t\t_update_repo; \\\n\t\t\tapt-get build-dep -y \"postgresql-$PG_MAJOR=$PG_VERSION\"; \\\n\t\t\tapt-get source --compile \"postgresql-$PG_MAJOR=$PG_VERSION\"; \\\n\t\t\t\\\n\t\t\t\\\n\t\t\tapt-mark showmanual | xargs apt-mark auto > /dev/null; \\\n\t\t\tapt-mark manual $savedAptMark; \\\n\t\t\t\\\n\t\t\tls -lAFh; \\\n\t\t\t_update_repo; \\\n\t\t\tgrep '^Package: ' Packages; \\\n\t\t\tcd /; \\\n\t\t\t;; \\\n\tesac; \\\n\t\\\n\tapt-get install -y --no-install-recommends postgresql-common; \\\n\tsed -ri 's/#(create_main_cluster) .*$/\\1 = false/' /etc/postgresql-common/createcluster.conf; \\\n\tapt-get install -y --no-install-recommends \\\n\t\t\"postgresql-$PG_MAJOR=$PG_VERSION\" \\\n\t; \\\n\t\\\n\trm -rf /var/lib/apt/lists/*; \\\n\t\\\n\tif [ -n \"$tempDir\" ]; then \\\n\t\tapt-get purge -y --auto-remove; \\\n\t\trm -rf \"$tempDir\" /etc/apt/sources.list.d/temp.list; \\\n\tfi; \\\n\t\\\n\tfind /usr -name '*.pyc' -type f -exec bash -c 'for pyc; do dpkg -S \"$pyc\" &> /dev/null || rm -vf \"$pyc\"; done' -- '{}' +; \\\n\t\\\n\tpostgres --version"]

# make the sample config easier to munge (and "correct by default")
RUN set -eux; \
	dpkg-divert --add --rename --divert "/usr/share/postgresql/postgresql.conf.sample.dpkg" "/usr/share/postgresql/$PG_MAJOR/postgresql.conf.sample"; \
	cp -v /usr/share/postgresql/postgresql.conf.sample.dpkg /usr/share/postgresql/postgresql.conf.sample; \
	ln -sv ../postgresql.conf.sample "/usr/share/postgresql/$PG_MAJOR/"; \
	sed -ri "s!^#?(listen_addresses)\s*=\s*\S+.*!\1 = '*'!" /usr/share/postgresql/postgresql.conf.sample; \
	grep -F "listen_addresses = '*'" /usr/share/postgresql/postgresql.conf.sample

RUN install --verbose --directory --owner postgres --group postgres --mode 3777 /var/run/postgresql

ENV PGDATA /var/lib/postgresql/data
# this 1777 will be replaced by 0700 at runtime (allows semi-arbitrary "--user" values)
RUN install --verbose --directory --owner postgres --group postgres --mode 1777 "$PGDATA"
VOLUME /var/lib/postgresql/data

COPY docker-entrypoint.sh docker-ensure-initdb.sh /usr/local/bin/
RUN ln -sT docker-ensure-initdb.sh /usr/local/bin/docker-enforce-initdb.sh
ENTRYPOINT ["docker-entrypoint.sh"]

# We set the default STOPSIGNAL to SIGINT, which corresponds to what PostgreSQL
# calls "Fast Shutdown mode" wherein new connections are disallowed and any
# in-progress transactions are aborted, allowing PostgreSQL to stop cleanly and
# flush tables to disk.
#
# See https://www.postgresql.org/docs/current/server-shutdown.html for more details
# about available PostgreSQL server shutdown signals.
#
# See also https://www.postgresql.org/docs/current/server-start.html for further
# justification of this as the default value, namely that the example (and
# shipped) systemd service files use the "Fast Shutdown mode" for service
# termination.
#
STOPSIGNAL SIGINT
#
# An additional setting that is recommended for all users regardless of this
# value is the runtime "--stop-timeout" (or your orchestrator/runtime's
# equivalent) for controlling how long to wait between sending the defined
# STOPSIGNAL and sending SIGKILL.
#
# The default in most runtimes (such as Docker) is 10 seconds, and the
# documentation at https://www.postgresql.org/docs/current/server-start.html notes
# that even 90 seconds may not be long enough in many instances.

EXPOSE 5432
CMD ["postgres"]
