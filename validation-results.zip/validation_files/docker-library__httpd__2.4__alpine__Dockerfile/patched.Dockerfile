FROM alpine:3.24

# ensure www-data user exists
RUN set -x \
	&& adduser -u 82 -D -S -G www-data www-data
# 82 is the standard uid/gid for "www-data" in Alpine
# https://git.alpinelinux.org/cgit/aports/tree/main/apache2/apache2.pre-install?h=v3.14.0
# https://git.alpinelinux.org/cgit/aports/tree/main/lighttpd/lighttpd.pre-install?h=v3.14.0
# https://git.alpinelinux.org/cgit/aports/tree/main/nginx/nginx.pre-install?h=v3.14.0

ENV HTTPD_PREFIX /usr/local/apache2
ENV PATH $HTTPD_PREFIX/bin:$PATH
RUN mkdir -p "$HTTPD_PREFIX" \
	&& chown www-data:www-data "$HTTPD_PREFIX"
WORKDIR $HTTPD_PREFIX

# install httpd runtime dependencies
# https://httpd.apache.org/docs/2.4/install.html#requirements
# TODO(flakiscan): could not automatically fix: DL3018
RUN set -eux; \
	apk add --no-cache \
		apr \
		apr-util \
		apr-util-ldap \
# https://github.com/docker-library/httpd/issues/214
		ca-certificates \
		perl \
	;

ENV HTTPD_VERSION 2.4.68
ENV HTTPD_SHA256 68c74d4df38c26bed4dfbdb8f3baf1eb532f3872357becc1bba5d136f6b63c06

# https://httpd.apache.org/security/vulnerabilities_24.html
ENV HTTPD_PATCHES=""

# see https://httpd.apache.org/docs/2.4/install.html#requirements
# TODO(flakiscan): could not automatically fix: DL3018, DL3019
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tapk add --no-cache --virtual .build-deps \\\n\t\tapr-dev \\\n\t\tapr-util-dev \\\n\t\tcoreutils \\\n\t\tdpkg-dev dpkg \\\n\t\tgcc \\\n\t\tgnupg \\\n\t\tlibc-dev \\\n\t\tpatch \\\n\t\tcurl-dev \\\n\t\tjansson-dev \\\n\t\tlibxml2-dev \\\n\t\tlua-dev \\\n\t\tmake \\\n\t\tnghttp2-dev \\\n\t\topenssl \\\n\t\topenssl-dev \\\n\t\tpcre-dev \\\n\t\ttar \\\n\t\tzlib-dev \\\n\t\tbrotli-dev \\\n\t; \\\n\t\\\n\tddist() { \\\n\t\tlocal f=\"$1\"; shift; \\\n\t\tlocal distFile=\"$1\"; shift; \\\n\t\tlocal success=; \\\n\t\tlocal distUrl=; \\\n\t\tfor distUrl in \\\n\t\t\t'https://www.apache.org/dyn/closer.cgi?action=download&filename=' \\\n\t\t\thttps://downloads.apache.org/ \\\n\t\t\thttps://www-us.apache.org/dist/ \\\n\t\t\thttps://www.apache.org/dist/ \\\n\t\t\thttps://archive.apache.org/dist/ \\\n\t\t; do \\\n\t\t\tif wget -O \"$f\" \"$distUrl$distFile\" && [ -s \"$f\" ]; then \\\n\t\t\t\tsuccess=1; \\\n\t\t\t\tbreak; \\\n\t\t\tfi; \\\n\t\tdone; \\\n\t\t[ -n \"$success\" ]; \\\n\t}; \\\n\t\\\n\tddist 'httpd.tar.bz2' \"httpd/httpd-$HTTPD_VERSION.tar.bz2\"; \\\n\techo \"$HTTPD_SHA256 *httpd.tar.bz2\" | sha256sum -c -; \\\n\t\\\n\tddist 'httpd.tar.bz2.asc' \"httpd/httpd-$HTTPD_VERSION.tar.bz2.asc\"; \\\n\texport GNUPGHOME=\"$(mktemp -d)\"; \\\n\tfor key in \\\n\t\tDE29FB3971E71543FD2DC049508EAEC5302DA568 \\\n\t\t13155B0E9E634F42BF6C163FDDBA64BA2C312D2F \\\n\t\t8B39757B1D8A994DF2433ED58B3A601F08C975E5 \\\n\t\t31EE1A81B8D066548156D37B7D6DBFD1F08E012A \\\n\t\tA10208FEC3152DD7C0C9B59B361522D782AB7BD1 \\\n\t\t3DE024AFDA7A4B15CB6C14410F81AA8AB0D5F771 \\\n\t\tEB138C6AF0FC691001B16D93344A844D751D7F27 \\\n\t\tCBA5A7C21EC143314C41393E5B968010E04F9A89 \\\n\t\t3C016F2B764621BB549C66B516A96495E2226795 \\\n\t\t937FB3994A242BA9BF49E93021454AF0CC8B0F7E \\\n\t\tEAD1359A4C0F2D37472AAF28F55DF0293A4E7AC9 \\\n\t\t4C1EADADB4EF5007579C919C6635B6C0DE885DD3 \\\n\t\t01E475360FCCF1D0F24B9D145D414AE1E005C9CB \\\n\t\t92CCEF0AA7DD46AC3A0F498BCA6939748103A37E \\\n\t\tD395C7573A68B9796D38C258153FA0CD75A67692 \\\n\t\tFA39B617B61493FD283503E7EED1EA392261D073 \\\n\t\t984FB3350C1D5C7A3282255BB31B213D208F5064 \\\n\t\tFE7A49DAA875E890B4167F76CCB2EB46E76CF6D0 \\\n\t\t39F6691A0ECF0C50E8BB849CF78875F642721F00 \\\n\t\t29A2BA848177B73878277FA475CAA2A3F39B3750 \\\n\t\t120A8667241AEDD4A78B46104C042818311A3DE5 \\\n\t\t453510BDA6C5855624E009236D0BC73A40581837 \\\n\t\t0DE5C55C6BF3B2352DABB89E13249B4FEC88A0BF \\\n\t\t7CDBED100806552182F98844E8E7E00B4DAA1988 \\\n\t\tA8BA9617EF3BCCAC3B29B869EDB105896F9522D8 \\\n\t\t3E6AC004854F3A7F03566B592FF06894E55B0D0E \\\n\t\t5B5181C2C0AB13E59DA3F7A3EC582EB639FF092C \\\n\t\tA93D62ECC3C8EA12DB220EC934EA76E6791485A8 \\\n\t\t65B2D44FE74BD5E3DE3AC3F082781DE46D5954FA \\\n\t\t8935926745E1CE7E3ED748F6EC99EE267EB5F61A \\\n\t\tE3480043595621FE56105F112AB12A7ADC55C003 \\\n\t\t93525CFCF6FDFFB3FD9700DD5A4B10AE43B56A27 \\\n\t\tC55AB7B9139EB2263CD1AABC19B033D1760C227B \\\n\t\t26F51EF9A82F4ACB43F1903ED377C9E7D1944C66 \\\n\t; do \\\n\t\tgpg --batch --keyserver keyserver.ubuntu.com --recv-keys \"$key\"; \\\n\tdone; \\\n\tgpg --batch --verify httpd.tar.bz2.asc httpd.tar.bz2; \\\n\tcommand -v gpgconf && gpgconf --kill all || :; \\\n\trm -rf \"$GNUPGHOME\" httpd.tar.bz2.asc; \\\n\t\\\n\tmkdir -p src; \\\n\ttar -xf httpd.tar.bz2 -C src --strip-components=1; \\\n\trm httpd.tar.bz2; \\\n\tcd src; \\\n\t\\\n\tpatches() { \\\n\t\twhile [ \"$#\" -gt 0 ]; do \\\n\t\t\tlocal patchFile=\"$1\"; shift; \\\n\t\t\tlocal patchSha256=\"$1\"; shift; \\\n\t\t\tddist \"$patchFile\" \"httpd/patches/apply_to_$HTTPD_VERSION/$patchFile\"; \\\n\t\t\techo \"$patchSha256 *$patchFile\" | sha256sum -c -; \\\n\t\t\tpatch -p0 < \"$patchFile\"; \\\n\t\t\trm -f \"$patchFile\"; \\\n\t\tdone; \\\n\t}; \\\n\tpatches $HTTPD_PATCHES; \\\n\t\\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\t./configure \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--prefix=\"$HTTPD_PREFIX\" \\\n\t\t--enable-mods-shared=reallyall \\\n\t\t--enable-mpms-shared=all \\\n\t; \\\n\tmake -j \"$(nproc)\"; \\\n\tmake install; \\\n\t\\\n\tcd ..; \\\n\trm -r src man manual; \\\n\t\\\n\tsed -ri \\\n\t\t-e 's!^(\\s*CustomLog)\\s+\\S+!\\1 /proc/self/fd/1!g' \\\n\t\t-e 's!^(\\s*ErrorLog)\\s+\\S+!\\1 /proc/self/fd/2!g' \\\n\t\t-e 's!^(\\s*TransferLog)\\s+\\S+!\\1 /proc/self/fd/1!g' \\\n\t\t-e 's!^(\\s*User)\\s+daemon\\s*$!\\1 www-data!g' \\\n\t\t-e 's!^(\\s*Group)\\s+daemon\\s*$!\\1 www-data!g' \\\n\t\t\"$HTTPD_PREFIX/conf/httpd.conf\" \\\n\t\t\"$HTTPD_PREFIX/conf/extra/httpd-ssl.conf\" \\\n\t; \\\n\tgrep -E '^\\s*User www-data$' \"$HTTPD_PREFIX/conf/httpd.conf\"; \\\n\tgrep -E '^\\s*Group www-data$' \"$HTTPD_PREFIX/conf/httpd.conf\"; \\\n\t\\\n\tdeps=\"$( \\\n\t\tscanelf --needed --nobanner --format '%n#p' --recursive /usr/local \\\n\t\t\t| tr ',' '\\n' \\\n\t\t\t| sort -u \\\n\t\t\t| awk 'system(\"[ -e /usr/local/lib/\" $1 \" ]\") == 0 { next } { print \"so:\" $1 }' \\\n\t)\"; \\\n\tapk add --no-network --virtual .httpd-so-deps $deps; \\\n\tapk del --no-network .build-deps; \\\n\t\\\n\thttpd -v"]

# https://httpd.apache.org/docs/2.4/stopping.html#gracefulstop
STOPSIGNAL SIGWINCH

COPY httpd-foreground /usr/local/bin/

EXPOSE 80
CMD ["httpd-foreground"]
