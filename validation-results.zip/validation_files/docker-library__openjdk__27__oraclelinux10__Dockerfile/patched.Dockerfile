#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM oraclelinux:10-slim

# TODO(flakiscan): could not automatically fix: DL3041
RUN set -eux; \
	microdnf install \
		gzip \
		tar \
		\
# jlink --strip-debug on 13+ needs objcopy: https://github.com/docker-library/openjdk/issues/351
# Error: java.io.IOException: Cannot run program "objcopy": error=2, No such file or directory
		binutils \
# java.lang.UnsatisfiedLinkError: /usr/java/openjdk-12/lib/libfontmanager.so: libfreetype.so.6: cannot open shared object file: No such file or directory
# https://github.com/docker-library/openjdk/pull/235#issuecomment-424466077
		freetype fontconfig \
	; \
	microdnf clean all

ENV JAVA_HOME /usr/java/openjdk-27
ENV PATH $JAVA_HOME/bin:$PATH

# Default to UTF-8 file.encoding
ENV LANG C.UTF-8

# https://jdk.java.net/
# >
# > Java Development Kit builds, from Oracle
# >
ENV JAVA_VERSION 27

# TODO(flakiscan): could not automatically fix: sha256sumEchoOneSpaces
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tarch=\"$(rpm --query --queryformat='%{ARCH}' rpm)\"; \\\n\tcase \"$arch\" in \\\n\t\t'x86_64') \\\n\t\t\tdownloadUrl='https://download.java.net/java/GA/jdk27/55ce5470a6294008af0057ff4626d0e5/35/GPL/openjdk-27_linux-x64_bin.tar.gz'; \\\n\t\t\tdownloadSha256='95fc37eb3a18a27a26d5904c2d89d52bace8dafa9a078ca27f4747fbc4bf070b'; \\\n\t\t\t;; \\\n\t\t'aarch64') \\\n\t\t\tdownloadUrl='https://download.java.net/java/GA/jdk27/55ce5470a6294008af0057ff4626d0e5/35/GPL/openjdk-27_linux-aarch64_bin.tar.gz'; \\\n\t\t\tdownloadSha256='da4e9dde1fff90204739e969187bab4751bd59a2a1c479672e1a1810f7dd23ea'; \\\n\t\t\t;; \\\n\t\t*) echo >&2 \"error: unsupported architecture: '$arch'\"; exit 1 ;; \\\n\tesac; \\\n\t\\\n\tcurl -fL -o openjdk.tgz \"$downloadUrl\"; \\\n\techo \"$downloadSha256 *openjdk.tgz\" | sha256sum --strict --check -; \\\n\t\\\n\tmkdir -p \"$JAVA_HOME\"; \\\n\ttar --extract \\\n\t\t--file openjdk.tgz \\\n\t\t--directory \"$JAVA_HOME\" \\\n\t\t--strip-components 1 \\\n\t\t--no-same-owner \\\n\t; \\\n\trm openjdk.tgz*; \\\n\t\\\n\trm -rf \"$JAVA_HOME/lib/security/cacerts\"; \\\n\tln -sT /etc/pki/ca-trust/extracted/java/cacerts \"$JAVA_HOME/lib/security/cacerts\"; \\\n\t\\\n\tln -sfT \"$JAVA_HOME\" /usr/java/default; \\\n\tln -sfT \"$JAVA_HOME\" /usr/java/latest; \\\n\tfor bin in \"$JAVA_HOME/bin/\"*; do \\\n\t\tbase=\"$(basename \"$bin\")\"; \\\n\t\t[ ! -e \"/usr/bin/$base\" ]; \\\n\t\talternatives --install \"/usr/bin/$base\" \"$base\" \"$bin\" 20000; \\\n\tdone; \\\n\t\\\n\tjava -Xshare:dump; \\\n\t\\\n\tfileEncoding=\"$(echo 'System.out.println(System.getProperty(\"file.encoding\"))' | jshell -s -)\"; [ \"$fileEncoding\" = 'UTF-8' ]; rm -rf ~/.java; \\\n\tjavac --version; \\\n\tjava --version"]

# "jshell" is an interactive REPL for Java (see https://en.wikipedia.org/wiki/JShell)
CMD ["jshell"]
