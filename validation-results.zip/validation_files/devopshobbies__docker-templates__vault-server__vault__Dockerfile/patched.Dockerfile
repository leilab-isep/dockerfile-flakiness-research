FROM alpine:3.14 AS preInstaller
RUN mkdir /etc/vault.d
# TODO(flakiscan): could not automatically fix: DL3018
RUN apk --no-cache add wget

FROM preInstaller
ARG VAULT_VERSION=1.12.2
# TODO(flakiscan): could not automatically fix: download_no_checksum
RUN wget --quiet --output-document=/tmp/vault.zip https://releases.hashicorp.com/vault/${VAULT_VERSION}/vault_${VAULT_VERSION}_linux_amd64.zip && \
    unzip /tmp/vault.zip -d /bin && \
    rm -f /tmp/vault.zip
    
EXPOSE 8200 8201
