#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM alpine:3.24

# ensure local python is preferred over distribution python
ENV PATH /usr/local/bin:$PATH

# runtime dependencies
# TODO(flakiscan): could not automatically fix: DL3018
RUN set -eux; \
	apk add --no-cache \
		ca-certificates \
		tzdata \
	;

ENV PYTHON_VERSION 3.15.0rc2
ENV PYTHON_SHA256 8d93af5eaaaea5adfd41bd786a7ba3f03f2ad1ab57c6a65e0b963deab91d5ad7

# TODO(flakiscan): could not automatically fix: DL3018, sha256sumEchoOneSpaces
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tapk add --no-cache --virtual .build-deps \\\n\t\tbluez-dev \\\n\t\tbzip2-dev \\\n\t\tdpkg-dev dpkg \\\n\t\tfindutils \\\n\t\tg++ \\\n\t\tgcc \\\n\t\tgdbm-dev \\\n\t\tgnupg \\\n\t\tlibc-dev \\\n\t\tlibffi-dev \\\n\t\tlibnsl-dev \\\n\t\tlibtirpc-dev \\\n\t\tlinux-headers \\\n\t\tmake \\\n\t\tncurses-dev \\\n\t\topenssl-dev \\\n\t\tpax-utils \\\n\t\treadline-dev \\\n\t\tsqlite-dev \\\n\t\ttar \\\n\t\ttcl-dev \\\n\t\ttk \\\n\t\ttk-dev \\\n\t\tutil-linux-dev \\\n\t\txz \\\n\t\txz-dev \\\n\t\tzlib-dev \\\n\t\tzstd-dev \\\n\t; \\\n\t\\\n\twget -O python.tar.xz \"https://www.python.org/ftp/python/${PYTHON_VERSION%%[a-z]*}/Python-$PYTHON_VERSION.tar.xz\"; \\\n\techo \"$PYTHON_SHA256 *python.tar.xz\" | sha256sum -c -; \\\n\tmkdir -p /usr/src/python; \\\n\ttar --extract --directory /usr/src/python --strip-components=1 --file python.tar.xz; \\\n\trm python.tar.xz; \\\n\t\\\n\tcd /usr/src/python; \\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\t./configure \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--enable-loadable-sqlite-extensions \\\n\t\t--enable-option-checking=fatal \\\n\t\t--enable-shared \\\n\t\t$(test \"${gnuArch%%-*}\" != 'riscv64' && echo '--with-lto') \\\n\t\t--with-ensurepip \\\n\t; \\\n\tnproc=\"$(nproc)\"; \\\n\tEXTRA_CFLAGS=\"-DTHREAD_STACK_SIZE=0x100000\"; \\\n\tLDFLAGS=\"${LDFLAGS:-} -Wl,--strip-all\"; \\\n\tarch=\"$(apk --print-arch)\"; \\\n\tcase \"$arch\" in \\\n\t\tx86_64|aarch64) \\\n\t\t\tEXTRA_CFLAGS=\"${EXTRA_CFLAGS:-} -fno-omit-frame-pointer -mno-omit-leaf-frame-pointer\"; \\\n\t\t\t;; \\\n\t\tx86) \\\n\t\t\t;; \\\n\t\t*) \\\n\t\t\tEXTRA_CFLAGS=\"${EXTRA_CFLAGS:-} -fno-omit-frame-pointer\"; \\\n\t\t\t;; \\\n\tesac; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-}\" \\\n\t; \\\n\trm python; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-} -Wl,-rpath='\\$\\$ORIGIN/../lib'\" \\\n\t\tpython \\\n\t; \\\n\tmake install; \\\n\t\\\n\tcd /; \\\n\trm -rf /usr/src/python; \\\n\t\\\n\tfind /usr/local -depth \\\n\t\t\\( \\\n\t\t\t\\( -type d -a \\( -name test -o -name tests -o -name idle_test \\) \\) \\\n\t\t\t-o \\( -type f -a \\( -name '*.pyc' -o -name '*.pyo' -o -name 'libpython*.a' \\) \\) \\\n\t\t\\) -exec rm -rf '{}' + \\\n\t; \\\n\t\\\n\tfind /usr/local -type f -executable -not \\( -name '*tkinter*' \\) -exec scanelf --needed --nobanner --format '%n#p' '{}' ';' \\\n\t\t| tr ',' '\\n' \\\n\t\t| sort -u \\\n\t\t| awk 'system(\"[ -e /usr/local/lib/\" $1 \" ]\") == 0 { next } { print \"so:\" $1 }' \\\n\t\t| xargs -rt apk add --no-network --virtual .python-rundeps \\\n\t; \\\n\tapk del --no-network .build-deps; \\\n\t\\\n\texport PYTHONDONTWRITEBYTECODE=1; \\\n\tpython3 --version; \\\n\tpip3 --version"]

# make some useful symlinks that are expected to exist ("/usr/local/bin/python" and friends)
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tfor src in idle3 pip3 pydoc3 python3 python3-config; do \\\n\t\tdst=\"$(echo \"$src\" | tr -d 3)\"; \\\n\t\t[ -s \"/usr/local/bin/$src\" ]; \\\n\t\t[ ! -e \"/usr/local/bin/$dst\" ]; \\\n\t\tln -svT \"$src\" \"/usr/local/bin/$dst\"; \\\n\tdone"]

CMD ["python3"]
