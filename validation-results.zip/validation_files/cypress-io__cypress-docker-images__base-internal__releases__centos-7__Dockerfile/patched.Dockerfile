# build it with command
#   docker build -t cypress/centos7-builder . --platform linux/amd64 .
#
FROM centos:7

# Update repo URLs to point to vault.centos.org
RUN     ["/bin/bash", "-o", "pipefail", "-c", "for repo in /etc/yum.repos.d/*.repo; do \\\n            sed -i 's|mirrorlist=|#mirrorlist=|g' $repo; \\\n            sed -i 's|#baseurl=http://mirror.centos.org|baseurl=http://vault.centos.org|g' $repo; \\\n            sed -i 's|http://mirror.centos.org|http://vault.centos.org|g' $repo; \\\n        done && yum clean all"]

# Install centos-release-scl to get the SCL repositories
# TODO(flakiscan): could not automatically fix: DL3033, yumInstallRmVarCacheYum
RUN     yum -y install centos-release-scl

# Update repo URLs to point to vault.centos.org again
RUN     ["/bin/bash", "-o", "pipefail", "-c", "for repo in /etc/yum.repos.d/CentOS-SCLo-scl*.repo; do \\\n            sed -i 's|mirrorlist=|#mirrorlist=|g' $repo; \\\n            sed -i 's|# baseurl=http://mirror.centos.org|baseurl=http://vault.centos.org|g' $repo; \\\n            sed -i 's|#baseurl=http://mirror.centos.org|baseurl=http://vault.centos.org|g' $repo; \\\n            sed -i 's|http://mirror.centos.org|http://vault.centos.org|g' $repo; \\\n        done && yum clean all"]

# Install dependencies for building the addon and setting devtoolset-8 as the default compiler
# TODO(flakiscan): could not automatically fix: DL3033, yumInstallRmVarCacheYum
RUN yum -y install curl python3 make atk-devel atk java-atk-wrapper at-spi2-atk gtk3 libXt libdrm mesa-libgbm Xvfb devtoolset-8-gcc devtoolset-8-gcc-c++
RUN echo >> /etc/profile.d/devtoolset-8.sh 'source scl_source enable devtoolset-8'
RUN ["/bin/bash", "-o", "pipefail", "-c", "curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh -o /tmp/install.sh && sha256sum /tmp/install.sh && bash /tmp/install.sh"]
RUN echo >> /etc/profile.d/nvm.sh 'source ~/.nvm/nvm.sh'
# Node 16 is the most recent version that supports CentOS 7. We only need it to call the
# build script for lib/addon, so there should be minimal risk of security issues.
RUN source ~/.nvm/nvm.sh && nvm install 16.20.2 && npm install -g yarn@1.22.22 && npm cache clean --force
