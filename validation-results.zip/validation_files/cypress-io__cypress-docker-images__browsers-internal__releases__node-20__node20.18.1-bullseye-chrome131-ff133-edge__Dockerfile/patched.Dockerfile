# build this image with command
#   docker build -t cypress/browsers-internal:node20.18.1-bullseye-chrome131-ff133-edge --platform linux/amd64 .
#

FROM cypress/browsers-internal:node20.18.1-bullseye-chrome131-ff133

USER root

# Install dependencies
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && \
  apt-get install --no-install-recommends -y \
  # edge dependencies
  gnupg \
  dirmngr \
  \
  # clean up
  && rm -rf /var/lib/apt/lists/* \
  && apt-get clean

# install latest Edge
# TODO(flakiscan): could not automatically fix: DL3008, curlUseFlagF, curlUseFlagL
RUN ["/bin/bash", "-o", "pipefail", "-c", "node -p \"process.arch === 'arm64' ? 'Not downloading Edge since we are on arm64: https://techcommunity.microsoft.com/t5/discussions/edge-for-linux-arm64/m-p/1532272' : process.exit(1)\" || \\\n  (curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.gpg && \\\n  install -o root -g root -m 644 microsoft.gpg /etc/apt/trusted.gpg.d/ && \\\n  sh -c 'echo \"deb [arch=amd64] https://packages.microsoft.com/repos/edge stable main\" > /etc/apt/sources.list.d/microsoft-edge-dev.list' && \\\n  rm microsoft.gpg && \\\n  apt-get update && \\\n  apt-get install --no-install-recommends -y microsoft-edge-dev && \\\n  ln -s /usr/bin/microsoft-edge /usr/bin/edge) && rm -rf /var/lib/apt/lists/*"]

# install pnpm
RUN npm install -g pnpm@9 --force && npm cache clean --force

# versions of local tools
RUN echo  " node version:    $(node -v) \n" \
  "npm version:     $(npm -v) \n" \
  "yarn version:    $(yarn -v) \n" \
  "pnpm version:    $(pnpm -v) \n" \
  "debian version:  $(cat /etc/debian_version) \n" \
  "Chrome version:  $(google-chrome --version) \n" \
  "Firefox version: $(firefox --version) \n" \
  "Edge version:    n/a \n" \ 
  "git version:     $(git --version) \n" \
  "whoami:          $(whoami) \n"

