# builder stage
# from golang alpine image
FROM golang:1.19-alpine as builder

# Installing Git for alpine
# TODO(flakiscan): could not automatically fix: DL3018
RUN apk add --no-cache git

# create work directory called src
WORKDIR /src

# build argument for framework
ARG FRAMEWORK=echo

# copy go.mod and go.sum
COPY $FRAMEWORK/go.mod $FRAMEWORK/go.sum ./

# download dependencies
RUN go mod download

# copy other files
COPY $FRAMEWORK $FRAMEWORK

# build golang app
RUN CGO_ENABLED=0 GO111MODULE=on go build -v -o /main -installsuffix cgo -ldflags="-w -s" ./$FRAMEWORK/*.go

# second stage
FROM alpine@sha256:28bd5fe8b56d1bd048e5babf5b10710ebe0bae67db86916198a6eec434943f8b

# copy executable file
COPY --from=builder /main .

# allow main to be executed
RUN chmod +x /main

# expose port 80
EXPOSE 80

# run app executable file
CMD ["./main"]
