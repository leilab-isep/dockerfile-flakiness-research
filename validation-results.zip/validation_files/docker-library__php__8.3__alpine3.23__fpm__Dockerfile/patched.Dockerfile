#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM alpine:3.23

# dependencies required for running "phpize"
# these get automatically installed and removed by "docker-php-ext-*" (unless they're already installed)
ENV PHPIZE_DEPS \
		autoconf \
		dpkg-dev dpkg \
		file \
		g++ \
		gcc \
		libc-dev \
		make \
		pkgconf \
		re2c

# persistent / runtime deps
# TODO(flakiscan): could not automatically fix: DL3018
RUN apk add --no-cache \
		ca-certificates \
		curl \
		openssl \
		tar \
		xz

# ensure www-data user exists
RUN set -eux; \
	adduser -u 82 -D -S -G www-data www-data
# 82 is the standard uid/gid for "www-data" in Alpine
# https://git.alpinelinux.org/aports/tree/main/apache2/apache2.pre-install?h=3.14-stable
# https://git.alpinelinux.org/aports/tree/main/lighttpd/lighttpd.pre-install?h=3.14-stable
# https://git.alpinelinux.org/aports/tree/main/nginx/nginx.pre-install?h=3.14-stable

ENV PHP_INI_DIR /usr/local/etc/php
RUN set -eux; \
	mkdir -p "$PHP_INI_DIR/conf.d"; \
# allow running as an arbitrary user (https://github.com/docker-library/php/issues/743)
	[ ! -d /var/www/html ]; \
	mkdir -p /var/www/html; \
	chown www-data:www-data /var/www/html; \
	chmod 1777 /var/www/html

# Apply stack smash protection to functions using local buffers and alloca()
# Make PHP's main executable position-independent (improves ASLR security mechanism, and has no performance impact on x86_64)
# Enable optimization (-O2)
# Enable linker optimization (this sorts the hash buckets to improve cache locality, and is non-default)
# https://github.com/docker-library/php/issues/272
# -D_LARGEFILE_SOURCE and -D_FILE_OFFSET_BITS=64 (https://www.php.net/manual/en/intro.filesystem.php)
ENV PHP_CFLAGS="-fstack-protector-strong -fpic -fpie -O2 -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64"
ENV PHP_CPPFLAGS="$PHP_CFLAGS"
ENV PHP_LDFLAGS="-Wl,-O1 -pie"

ENV GPG_KEYS 1198C0117593497A5EC5C199286AF1F9897469DC C28D937575603EB4ABB725861C0779DC5C0A9DE4 AFD8691FDAEDF03BDF6E460563F15A9B715376CA

ENV PHP_VERSION 8.3.33
ENV PHP_URL="https://www.php.net/distributions/php-8.3.33.tar.xz" PHP_ASC_URL="https://www.php.net/distributions/php-8.3.33.tar.xz.asc"
ENV PHP_SHA256="e293ed620cec74651bb4a071317892a478aa6840fab22db45c72d77cd42f9676"

# TODO(flakiscan): could not automatically fix: DL3018, sha256sumEchoOneSpaces
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tapk add --no-cache --virtual .fetch-deps gnupg; \\\n\t\\\n\tmkdir -p /usr/src; \\\n\tcd /usr/src; \\\n\t\\\n\tcurl -fsSL -o php.tar.xz \"$PHP_URL\"; \\\n\t\\\n\tif [ -n \"$PHP_SHA256\" ]; then \\\n\t\techo \"$PHP_SHA256 *php.tar.xz\" | sha256sum -c -; \\\n\tfi; \\\n\t\\\n\tcurl -fsSL -o php.tar.xz.asc \"$PHP_ASC_URL\"; \\\n\texport GNUPGHOME=\"$(mktemp -d)\"; \\\n\tfor key in $GPG_KEYS; do \\\n\t\tgpg --batch --keyserver keyserver.ubuntu.com --recv-keys \"$key\"; \\\n\tdone; \\\n\tgpg --batch --verify php.tar.xz.asc php.tar.xz; \\\n\tgpgconf --kill all; \\\n\trm -rf \"$GNUPGHOME\"; \\\n\t\\\n\tapk del --no-network .fetch-deps"]

COPY docker-php-source /usr/local/bin/

# TODO(flakiscan): could not automatically fix: DL3018
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\tapk add --no-cache --virtual .build-deps \\\n\t\t$PHPIZE_DEPS \\\n\t\targon2-dev \\\n\t\tcoreutils \\\n\t\tcurl-dev \\\n\t\tgnu-libiconv-dev \\\n\t\tlibsodium-dev \\\n\t\tlibxml2-dev \\\n\t\tlinux-headers \\\n\t\toniguruma-dev \\\n\t\topenssl-dev \\\n\t\treadline-dev \\\n\t\tsqlite-dev \\\n\t; \\\n\t\\\n\trm -vf /usr/include/iconv.h; \\\n\t\\\n\texport \\\n\t\tCFLAGS=\"$PHP_CFLAGS\" \\\n\t\tCPPFLAGS=\"$PHP_CPPFLAGS\" \\\n\t\tLDFLAGS=\"$PHP_LDFLAGS\" \\\n\t\tPHP_BUILD_PROVIDER='https://github.com/docker-library/php' \\\n\t\tPHP_UNAME='Linux - Docker' \\\n\t; \\\n\tdocker-php-source extract; \\\n\tcd /usr/src/php; \\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\ttest \"$PHP_INI_DIR\" != \"${PHP_INI_DIR%/php}\"; \\\n\t./configure \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--sysconfdir=\"${PHP_INI_DIR%/php}\" \\\n\t\t--with-config-file-path=\"$PHP_INI_DIR\" \\\n\t\t--with-config-file-scan-dir=\"$PHP_INI_DIR/conf.d\" \\\n\t\t\\\n\t\t--enable-option-checking=fatal \\\n\t\t\\\n\t\t--with-mhash \\\n\t\t\\\n\t\t--with-pic \\\n\t\t\\\n\t\t--enable-mbstring \\\n\t\t--enable-mysqlnd \\\n\t\t--with-password-argon2 \\\n\t\t--with-sodium=shared \\\n\t\t--with-pdo-sqlite=/usr \\\n\t\t--with-sqlite3=/usr \\\n\t\t\\\n\t\t--with-curl \\\n\t\t--with-iconv=/usr \\\n\t\t--with-openssl \\\n\t\t--with-readline \\\n\t\t--with-zlib \\\n\t\t\\\n\t\t--disable-phpdbg \\\n\t\t\\\n\t\t--with-pear \\\n\t\t\\\n\t\t\\\n\t\t--disable-cgi \\\n\t\t\\\n\t\t--enable-fpm \\\n\t\t--with-fpm-user=www-data \\\n\t\t--with-fpm-group=www-data \\\n\t; \\\n\tmake -j \"$(nproc)\"; \\\n\tfind -type f -name '*.a' -delete; \\\n\tmake install; \\\n\tfind \\\n\t\t/usr/local \\\n\t\t-type f \\\n\t\t-perm '/0111' \\\n\t\t-exec sh -euxc ' \\\n\t\t\tstrip --strip-all \"$@\" || : \\\n\t\t' -- '{}' + \\\n\t; \\\n\tmake clean; \\\n\t\\\n\tcp -v php.ini-* \"$PHP_INI_DIR/\"; \\\n\t\\\n\tcd /; \\\n\tdocker-php-source delete; \\\n\t\\\n\trunDeps=\"$( \\\n\t\tscanelf --needed --nobanner --format '%n#p' --recursive /usr/local \\\n\t\t\t| tr ',' '\\n' \\\n\t\t\t| sort -u \\\n\t\t\t| awk 'system(\"[ -e /usr/local/lib/\" $1 \" ]\") == 0 { next } { print \"so:\" $1 }' \\\n\t)\"; \\\n\tapk add --no-cache $runDeps; \\\n\t\\\n\tapk del --no-network .build-deps; \\\n\t\\\n\tpecl update-channels; \\\n\trm -rf /tmp/pear ~/.pearrc; \\\n\t\\\n\tphp --version"]

COPY docker-php-ext-* docker-php-entrypoint /usr/local/bin/

# enable OPcache by default (https://wiki.php.net/rfc/make_opcache_required)
RUN docker-php-ext-enable opcache

# sodium was built as a shared module (so that it can be replaced later if so desired), so let's enable it too (https://github.com/docker-library/php/issues/598)
RUN docker-php-ext-enable sodium

ENTRYPOINT ["docker-php-entrypoint"]
WORKDIR /var/www/html

RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tcd \"${PHP_INI_DIR%/php}\"; \\\n\t\\\n\tcp -v php-fpm.conf.default php-fpm.conf; \\\n\tcp -v php-fpm.d/www.conf.default php-fpm.d/www.conf; \\\n\t\\\n\tgrep -E '^listen = 127.0.0.1:9000' php-fpm.d/www.conf; \\\n\tsed -ri 's/^(listen = 127.0.0.1:9000)/;\\1/' php-fpm.d/www.conf; \\\n\tgrep -E '^;listen = 127.0.0.1:9000' php-fpm.d/www.conf; \\\n\t\\\n\t{ \\\n\t\techo '[global]'; \\\n\t\techo 'error_log = /proc/self/fd/2'; \\\n\t\techo; echo '; https://github.com/docker-library/php/pull/725#issuecomment-443540114'; echo 'log_limit = 8192'; \\\n\t\techo; \\\n\t\techo '[www]'; \\\n\t\techo '; php-fpm closes STDOUT on startup, so sending logs to /proc/self/fd/1 does not work.'; \\\n\t\techo '; https://bugs.php.net/bug.php?id=73886'; \\\n\t\techo 'access.log = /proc/self/fd/2'; \\\n\t\techo; \\\n\t\techo 'clear_env = no'; \\\n\t\techo; \\\n\t\techo '; Ensure worker stdout and stderr are sent to the main error log.'; \\\n\t\techo 'catch_workers_output = yes'; \\\n\t\techo 'decorate_workers_output = no'; \\\n\t\techo; \\\n\t\techo '; default listen address for easy override in later php-fpm.d/*.conf files'; \\\n\t\techo 'listen = 9000'; \\\n\t} | tee php-fpm.d/docker.conf; \\\n\t{ \\\n\t\techo '[global]'; \\\n\t\techo 'daemonize = no'; \\\n\t\techo; \\\n\t\techo '; the [www] ini section below is for backwards compatibility and will be removed in 8.6+'; \\\n\t\techo '[www]'; \\\n\t} | tee php-fpm.d/zz-docker.conf; \\\n\tmkdir -p \"$PHP_INI_DIR/conf.d\"; \\\n\t{ \\\n\t\techo '; https://github.com/docker-library/php/issues/878#issuecomment-938595965'; \\\n\t\techo 'fastcgi.logging = Off'; \\\n\t} > \"$PHP_INI_DIR/conf.d/docker-fpm.ini\""]

# Override stop signal to stop process gracefully
# https://github.com/php/php-src/blob/17baa87faddc2550def3ae7314236826bc1b1398/sapi/fpm/php-fpm.8.in#L163
STOPSIGNAL SIGQUIT

EXPOSE 9000
CMD ["php-fpm"]
