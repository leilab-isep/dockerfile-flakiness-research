FROM cypress/factory@sha256:c717211343e3e21e8852dce9ca9f52377ce179ec16e01d8acbcd6fdd457c4bee
COPY . /opt/app
WORKDIR /opt/app
