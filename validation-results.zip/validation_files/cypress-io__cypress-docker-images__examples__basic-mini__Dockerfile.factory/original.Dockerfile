FROM cypress/factory
COPY . /opt/app
WORKDIR /opt/app
