FROM cypress/base@sha256:da5bab4c14ab67578ac7539603de2430d50240f29f7827dda7140e4e4bf6d023
COPY . /opt/app
WORKDIR /opt/app
RUN npx cypress install # Install Cypress binary into image
