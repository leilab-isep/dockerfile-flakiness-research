#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM debian:bookworm-slim

# ensure local python is preferred over distribution python
ENV PATH /usr/local/bin:$PATH

# runtime dependencies
# TODO(flakiscan): could not automatically fix: DL3008
RUN set -eux; \
	apt-get update; \
	apt-get install -y --no-install-recommends \
		ca-certificates \
		netbase \
		tzdata \
	; \
	rm -rf /var/lib/apt/lists/*

ENV PYTHON_VERSION 3.15.0rc2
ENV PYTHON_SHA256 8d93af5eaaaea5adfd41bd786a7ba3f03f2ad1ab57c6a65e0b963deab91d5ad7

# TODO(flakiscan): could not automatically fix: DL3008, sha256sumEchoOneSpaces
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tsavedAptMark=\"$(apt-mark showmanual)\"; \\\n\tapt-get update; \\\n\tapt-get install -y --no-install-recommends \\\n\t\tdpkg-dev \\\n\t\tg++ \\\n\t\tgcc \\\n\t\tgnupg \\\n\t\tlibbluetooth-dev \\\n\t\tlibbz2-dev \\\n\t\tlibc6-dev \\\n\t\tlibdb-dev \\\n\t\tlibffi-dev \\\n\t\tlibgdbm-dev \\\n\t\tliblzma-dev \\\n\t\tlibncursesw5-dev \\\n\t\tlibreadline-dev \\\n\t\tlibsqlite3-dev \\\n\t\tlibssl-dev \\\n\t\tlibzstd-dev \\\n\t\tmake \\\n\t\ttk-dev \\\n\t\tuuid-dev \\\n\t\twget \\\n\t\txz-utils \\\n\t\tzlib1g-dev \\\n\t; \\\n\t\\\n\twget -O python.tar.xz \"https://www.python.org/ftp/python/${PYTHON_VERSION%%[a-z]*}/Python-$PYTHON_VERSION.tar.xz\"; \\\n\techo \"$PYTHON_SHA256 *python.tar.xz\" | sha256sum -c -; \\\n\tmkdir -p /usr/src/python; \\\n\ttar --extract --directory /usr/src/python --strip-components=1 --file python.tar.xz; \\\n\trm python.tar.xz; \\\n\t\\\n\tcd /usr/src/python; \\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\t./configure \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--enable-loadable-sqlite-extensions \\\n\t\t--enable-optimizations \\\n\t\t--enable-option-checking=fatal \\\n\t\t--enable-shared \\\n\t\t$(test \"${gnuArch%%-*}\" != 'riscv64' && echo '--with-lto') \\\n\t\t--with-ensurepip \\\n\t; \\\n\tnproc=\"$(nproc)\"; \\\n\tEXTRA_CFLAGS=\"$(dpkg-buildflags --get CFLAGS)\"; \\\n\tLDFLAGS=\"$(dpkg-buildflags --get LDFLAGS)\"; \\\n\tLDFLAGS=\"${LDFLAGS:-} -Wl,--strip-all\"; \\\n\tarch=\"$(dpkg --print-architecture)\"; arch=\"${arch##*-}\"; \\\n\tcase \"$arch\" in \\\n\t\tamd64|arm64) \\\n\t\t\tEXTRA_CFLAGS=\"${EXTRA_CFLAGS:-} -fno-omit-frame-pointer -mno-omit-leaf-frame-pointer\"; \\\n\t\t\t;; \\\n\t\ti386) \\\n\t\t\t;; \\\n\t\t*) \\\n\t\t\tEXTRA_CFLAGS=\"${EXTRA_CFLAGS:-} -fno-omit-frame-pointer\"; \\\n\t\t\t;; \\\n\tesac; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-}\" \\\n\t; \\\n\trm python; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-} -Wl,-rpath='\\$\\$ORIGIN/../lib'\" \\\n\t\tpython \\\n\t; \\\n\tmake install; \\\n\t\\\n\tcd /; \\\n\trm -rf /usr/src/python; \\\n\t\\\n\tfind /usr/local -depth \\\n\t\t\\( \\\n\t\t\t\\( -type d -a \\( -name test -o -name tests -o -name idle_test \\) \\) \\\n\t\t\t-o \\( -type f -a \\( -name '*.pyc' -o -name '*.pyo' -o -name 'libpython*.a' \\) \\) \\\n\t\t\\) -exec rm -rf '{}' + \\\n\t; \\\n\t\\\n\tldconfig; \\\n\t\\\n\tapt-mark auto '.*' > /dev/null; \\\n\tapt-mark manual $savedAptMark; \\\n\tfind /usr/local -type f -executable -not \\( -name '*tkinter*' \\) -exec ldd '{}' ';' \\\n\t\t| awk '/=>/ { so = $(NF-1); if (index(so, \"/usr/local/\") == 1) { next }; gsub(\"^/(usr/)?\", \"\", so); printf \"*%s\\n\", so }' \\\n\t\t| sort -u \\\n\t\t| xargs -rt dpkg-query --search \\\n\t\t| awk 'sub(\":$\", \"\", $1) { print $1 }' \\\n\t\t| sort -u \\\n\t\t| xargs -r apt-mark manual \\\n\t; \\\n\tapt-get purge -y --auto-remove -o APT::AutoRemove::RecommendsImportant=false; \\\n\trm -rf /var/lib/apt/lists/*; \\\n\t\\\n\texport PYTHONDONTWRITEBYTECODE=1; \\\n\tpython3 --version; \\\n\tpip3 --version"]

# make some useful symlinks that are expected to exist ("/usr/local/bin/python" and friends)
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tfor src in idle3 pip3 pydoc3 python3 python3-config; do \\\n\t\tdst=\"$(echo \"$src\" | tr -d 3)\"; \\\n\t\t[ -s \"/usr/local/bin/$src\" ]; \\\n\t\t[ ! -e \"/usr/local/bin/$dst\" ]; \\\n\t\tln -svT \"$src\" \"/usr/local/bin/$dst\"; \\\n\tdone"]

CMD ["python3"]
