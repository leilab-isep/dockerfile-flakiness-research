#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM mcr.microsoft.com/windows/servercore:ltsc2022

SHELL ["powershell", "-Command", "$ErrorActionPreference = 'Stop'; $ProgressPreference = 'SilentlyContinue';"]

# https://github.com/docker-library/python/pull/557
ENV PYTHONIOENCODING UTF-8

ENV PYTHON_VERSION 3.14.7
ENV PYTHON_SHA256 9d9eb2709ef81bf5cd30db3c2096bdbc4ea10087c22e62f27d356b36f6ae9649

RUN ["/bin/bash", "-o", "pipefail", "-c", "$url = ('https://www.python.org/ftp/python/{0}/python-{1}-amd64.exe' -f ($env:PYTHON_VERSION -replace '[a-z]+[0-9]*$', ''), $env:PYTHON_VERSION); \\\n\tWrite-Host ('Downloading {0} ...' -f $url); \\\n\t[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; \\\n\tInvoke-WebRequest -Uri $url -OutFile 'python.exe'; \\\n\t\\\n\tWrite-Host ('Verifying sha256 ({0}) ...' -f $env:PYTHON_SHA256); \\\n\tif ((Get-FileHash python.exe -Algorithm sha256).Hash -ne $env:PYTHON_SHA256) { \\\n\t\tWrite-Host 'FAILED!'; \\\n\t\texit 1; \\\n\t}; \\\n\t\\\n\tWrite-Host 'Installing ...'; \\\n\t$exitCode = (Start-Process python.exe -Wait -NoNewWindow -PassThru \\\n\t\t-ArgumentList @( \\\n\t\t\t'/quiet', \\\n\t\t\t'InstallAllUsers=1', \\\n\t\t\t'TargetDir=C:\\Python', \\\n\t\t\t'PrependPath=1', \\\n\t\t\t'Shortcuts=0', \\\n\t\t\t'Include_doc=0', \\\n\t\t\t'Include_pip=1', \\\n\t\t\t'Include_test=0' \\\n\t\t) \\\n\t).ExitCode; \\\n\tif ($exitCode -ne 0) { \\\n\t\tWrite-Host ('Running python installer failed with exit code: {0}' -f $exitCode); \\\n\t\tGet-ChildItem $env:TEMP | Sort-Object -Descending -Property LastWriteTime | Select-Object -First 1 | Get-Content; \\\n\t\texit $exitCode; \\\n\t} \\\n\t\\\n\t$env:PATH = [Environment]::GetEnvironmentVariable('PATH', [EnvironmentVariableTarget]::Machine); \\\n\t\\\n\tWrite-Host 'Verifying install ...'; \\\n\tWrite-Host '  python --version'; python --version; \\\n\t\\\n\tWrite-Host 'Removing ...'; \\\n\tRemove-Item python.exe -Force; \\\n\tRemove-Item $env:TEMP/Python*.log -Force; \\\n\t\\\n\t$env:PYTHONDONTWRITEBYTECODE = '1'; \\\n\t\\\n\tWrite-Host 'Verifying pip install ...'; \\\n\tpip --version; \\\n\t\\\n\tWrite-Host 'Complete.'"]

CMD ["python"]
