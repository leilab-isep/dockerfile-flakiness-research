#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM alpine:3.24

# 70 is the standard uid/gid for "postgres" in Alpine
# https://git.alpinelinux.org/aports/tree/main/postgresql-common/postgresql-common.pre-install?h=3.22-stable
RUN set -eux; \
	addgroup -g 70 -S postgres; \
	adduser -u 70 -S -D -G postgres -H -h /var/lib/postgresql -s /bin/sh postgres; \
# also create the postgres user's home directory with appropriate permissions
# see https://github.com/docker-library/postgres/issues/274
	install --verbose --directory --owner postgres --group postgres --mode 1777 /var/lib/postgresql

# grab gosu for easy step-down from root
# https://github.com/tianon/gosu/releases
ENV GOSU_VERSION 1.19
# TODO(flakiscan): could not automatically fix: DL3018, download_no_checksum
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tapk add --no-cache --virtual .gosu-deps \\\n\t\tca-certificates \\\n\t\tdpkg \\\n\t\tgnupg \\\n\t; \\\n\t\\\n\tdpkgArch=\"$(dpkg --print-architecture | awk -F- '{ print $NF }')\"; \\\n\twget -O /usr/local/bin/gosu \"https://github.com/tianon/gosu/releases/download/$GOSU_VERSION/gosu-$dpkgArch\"; \\\n\twget -O /usr/local/bin/gosu.asc \"https://github.com/tianon/gosu/releases/download/$GOSU_VERSION/gosu-$dpkgArch.asc\"; \\\n\t\\\n\texport GNUPGHOME=\"$(mktemp -d)\"; \\\n\tgpg --batch --keyserver hkps://keys.openpgp.org --recv-keys B42F6819007F00F88E364FD4036A9C25BF357DD4; \\\n\tgpg --batch --verify /usr/local/bin/gosu.asc /usr/local/bin/gosu; \\\n\tgpgconf --kill all; \\\n\trm -rf \"$GNUPGHOME\" /usr/local/bin/gosu.asc; \\\n\t\\\n\tapk del --no-network .gosu-deps; \\\n\t\\\n\tchmod +x /usr/local/bin/gosu; \\\n\tgosu --version; \\\n\tgosu nobody true"]
RUN set -eux; ln -svf gosu /usr/local/bin/su-exec; su-exec nobody true # backwards compatibility (removed in PostgreSQL 17+)

# make the "en_US.UTF-8" locale so postgres will be utf-8 enabled by default
# alpine doesn't require explicit locale-file generation
ENV LANG en_US.utf8

RUN mkdir /docker-entrypoint-initdb.d

ENV PG_MAJOR 15
ENV PG_VERSION 15.19
ENV PG_SHA256 e1a64a87a46b825b88c082e4518161a47aab53c45694964f8ba1df28f7859f89

ENV DOCKER_PG_LLVM_DEPS \
		llvm21-dev \
		clang21

# TODO(flakiscan): could not automatically fix: DL3018, sha256sumEchoOneSpaces
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\twget -O postgresql.tar.bz2 \"https://ftp.postgresql.org/pub/source/v$PG_VERSION/postgresql-$PG_VERSION.tar.bz2\"; \\\n\techo \"$PG_SHA256 *postgresql.tar.bz2\" | sha256sum -c -; \\\n\tmkdir -p /usr/src/postgresql; \\\n\ttar \\\n\t\t--extract \\\n\t\t--file postgresql.tar.bz2 \\\n\t\t--directory /usr/src/postgresql \\\n\t\t--strip-components 1 \\\n\t; \\\n\trm postgresql.tar.bz2; \\\n\t\\\n\tapk add --no-cache --virtual .build-deps \\\n\t\t$DOCKER_PG_LLVM_DEPS \\\n\t\tbison \\\n\t\tcoreutils \\\n\t\tdpkg-dev dpkg \\\n\t\tflex \\\n\t\tg++ \\\n\t\tgcc \\\n\t\tkrb5-dev \\\n\t\tlibc-dev \\\n\t\tlibedit-dev \\\n\t\tlibxml2-dev \\\n\t\tlibxslt-dev \\\n\t\tlinux-headers \\\n\t\tmake \\\n\t\topenldap-dev \\\n\t\topenssl-dev \\\n\t\tperl-dev \\\n\t\tperl-ipc-run \\\n\t\tperl-utils \\\n\t\tpython3-dev \\\n\t\ttcl-dev \\\n\t\tutil-linux-dev \\\n\t\tzlib-dev \\\n\t\ticu-dev \\\n\t\tlz4-dev \\\n\t\tzstd-dev \\\n\t; \\\n\t\\\n\tcd /usr/src/postgresql; \\\n\tawk '$1 == \"#define\" && $2 == \"DEFAULT_PGSOCKET_DIR\" && $3 == \"\\\"/tmp\\\"\" { $3 = \"\\\"/var/run/postgresql\\\"\"; print; next } { print }' src/include/pg_config_manual.h > src/include/pg_config_manual.h.new; \\\n\tgrep '/var/run/postgresql' src/include/pg_config_manual.h.new; \\\n\tmv src/include/pg_config_manual.h.new src/include/pg_config_manual.h; \\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\t\\\n\texport LLVM_CONFIG=\"/usr/lib/llvm21/bin/llvm-config\"; \\\n\texport CLANG=clang-21; \\\n\t\\\n\t./configure \\\n\t\t--enable-option-checking=fatal \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--enable-integer-datetimes \\\n\t\t--enable-thread-safety \\\n\t\t--enable-tap-tests \\\n\t\t--disable-rpath \\\n\t\t--with-uuid=e2fs \\\n\t\t--with-gnu-ld \\\n\t\t--with-pgport=5432 \\\n\t\t--with-system-tzdata=/usr/share/zoneinfo \\\n\t\t--prefix=/usr/local \\\n\t\t--with-includes=/usr/local/include \\\n\t\t--with-libraries=/usr/local/lib \\\n\t\t--with-gssapi \\\n\t\t--with-icu \\\n\t\t--with-ldap \\\n\t\t--with-libxml \\\n\t\t--with-libxslt \\\n\t\t--with-llvm \\\n\t\t--with-lz4 \\\n\t\t--with-openssl \\\n\t\t--with-perl \\\n\t\t--with-python \\\n\t\t--with-tcl \\\n\t\t--with-zstd \\\n\t; \\\n\tmake -j \"$(nproc)\" world-bin; \\\n\tmake install-world-bin; \\\n\tmake -C contrib install; \\\n\t\\\n\trunDeps=\"$( \\\n\t\tscanelf --needed --nobanner --format '%n#p' --recursive /usr/local \\\n\t\t\t| tr ',' '\\n' \\\n\t\t\t| sort -u \\\n\t\t\t| awk 'system(\"[ -e /usr/local/lib/\" $1 \" ]\") == 0 { next } { print \"so:\" $1 }' \\\n\t\t\t| grep -v -e perl -e python -e tcl \\\n\t)\"; \\\n\tapk add --no-cache --virtual .postgresql-rundeps \\\n\t\t$runDeps \\\n\t\tbash \\\n\t\ttzdata \\\n\t\tzstd \\\n\t\ticu-data-full \\\n\t\t$([ \"$(apk --print-arch)\" != 'ppc64le' ] && echo 'nss_wrapper') \\\n\t; \\\n\tapk del --no-network .build-deps; \\\n\tcd /; \\\n\trm -rf \\\n\t\t/usr/src/postgresql \\\n\t\t/usr/local/share/doc \\\n\t\t/usr/local/share/man \\\n\t; \\\n\t\\\n\tpostgres --version"]

# make the sample config easier to munge (and "correct by default")
RUN set -eux; \
	cp -v /usr/local/share/postgresql/postgresql.conf.sample /usr/local/share/postgresql/postgresql.conf.sample.orig; \
	sed -ri "s!^#?(listen_addresses)\s*=\s*\S+.*!\1 = '*'!" /usr/local/share/postgresql/postgresql.conf.sample; \
	grep -F "listen_addresses = '*'" /usr/local/share/postgresql/postgresql.conf.sample

RUN install --verbose --directory --owner postgres --group postgres --mode 3777 /var/run/postgresql

ENV PGDATA /var/lib/postgresql/data
# this 1777 will be replaced by 0700 at runtime (allows semi-arbitrary "--user" values)
RUN install --verbose --directory --owner postgres --group postgres --mode 1777 "$PGDATA"
VOLUME /var/lib/postgresql/data

COPY docker-entrypoint.sh docker-ensure-initdb.sh /usr/local/bin/
RUN ln -sT docker-ensure-initdb.sh /usr/local/bin/docker-enforce-initdb.sh
ENTRYPOINT ["docker-entrypoint.sh"]

# We set the default STOPSIGNAL to SIGINT, which corresponds to what PostgreSQL
# calls "Fast Shutdown mode" wherein new connections are disallowed and any
# in-progress transactions are aborted, allowing PostgreSQL to stop cleanly and
# flush tables to disk.
#
# See https://www.postgresql.org/docs/current/server-shutdown.html for more details
# about available PostgreSQL server shutdown signals.
#
# See also https://www.postgresql.org/docs/current/server-start.html for further
# justification of this as the default value, namely that the example (and
# shipped) systemd service files use the "Fast Shutdown mode" for service
# termination.
#
STOPSIGNAL SIGINT
#
# An additional setting that is recommended for all users regardless of this
# value is the runtime "--stop-timeout" (or your orchestrator/runtime's
# equivalent) for controlling how long to wait between sending the defined
# STOPSIGNAL and sending SIGKILL.
#
# The default in most runtimes (such as Docker) is 10 seconds, and the
# documentation at https://www.postgresql.org/docs/current/server-start.html notes
# that even 90 seconds may not be long enough in many instances.

EXPOSE 5432
CMD ["postgres"]
