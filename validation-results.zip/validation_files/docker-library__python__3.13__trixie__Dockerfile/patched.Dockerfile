#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM buildpack-deps:trixie

# ensure local python is preferred over distribution python
ENV PATH /usr/local/bin:$PATH

# runtime dependencies
# TODO(flakiscan): could not automatically fix: DL3008
RUN set -eux; \
	apt-get update; \
	apt-get install -y --no-install-recommends \
		libbluetooth-dev \
		tk-dev \
		uuid-dev \
	; \
	apt-get dist-clean && rm -rf /var/lib/apt/lists/*

ENV GPG_KEY 7169605F62C751356D054A26A821E680E5FA6305
ENV PYTHON_VERSION 3.13.15
ENV PYTHON_SHA256 1e66a7945a48390ee4c2a4268a0e4185884059a13c4aab6d148aa208deea4a76

# TODO(flakiscan): could not automatically fix: sha256sumEchoOneSpaces
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\twget -O python.tar.xz \"https://www.python.org/ftp/python/${PYTHON_VERSION%%[a-z]*}/Python-$PYTHON_VERSION.tar.xz\"; \\\n\techo \"$PYTHON_SHA256 *python.tar.xz\" | sha256sum -c -; \\\n\twget -O python.tar.xz.asc \"https://www.python.org/ftp/python/${PYTHON_VERSION%%[a-z]*}/Python-$PYTHON_VERSION.tar.xz.asc\"; \\\n\tGNUPGHOME=\"$(mktemp -d)\"; export GNUPGHOME; \\\n\tgpg --batch --keyserver hkps://keys.openpgp.org --recv-keys \"$GPG_KEY\"; \\\n\tgpg --batch --verify python.tar.xz.asc python.tar.xz; \\\n\tgpgconf --kill all; \\\n\trm -rf \"$GNUPGHOME\" python.tar.xz.asc; \\\n\tmkdir -p /usr/src/python; \\\n\ttar --extract --directory /usr/src/python --strip-components=1 --file python.tar.xz; \\\n\trm python.tar.xz; \\\n\t\\\n\tcd /usr/src/python; \\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\t./configure \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--enable-loadable-sqlite-extensions \\\n\t\t--enable-optimizations \\\n\t\t--enable-option-checking=fatal \\\n\t\t--enable-shared \\\n\t\t$(test \"${gnuArch%%-*}\" != 'riscv64' && echo '--with-lto') \\\n\t\t--with-ensurepip \\\n\t; \\\n\tnproc=\"$(nproc)\"; \\\n\tEXTRA_CFLAGS=\"$(dpkg-buildflags --get CFLAGS)\"; \\\n\tLDFLAGS=\"$(dpkg-buildflags --get LDFLAGS)\"; \\\n\tarch=\"$(dpkg --print-architecture)\"; arch=\"${arch##*-}\"; \\\n\tcase \"$arch\" in \\\n\t\tamd64|arm64) \\\n\t\t\tEXTRA_CFLAGS=\"${EXTRA_CFLAGS:-} -fno-omit-frame-pointer -mno-omit-leaf-frame-pointer\"; \\\n\t\t\t;; \\\n\t\ti386) \\\n\t\t\t;; \\\n\t\t*) \\\n\t\t\tEXTRA_CFLAGS=\"${EXTRA_CFLAGS:-} -fno-omit-frame-pointer\"; \\\n\t\t\t;; \\\n\tesac; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-}\" \\\n\t; \\\n\trm python; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-} -Wl,-rpath='\\$\\$ORIGIN/../lib'\" \\\n\t\tpython \\\n\t; \\\n\tmake install; \\\n\t\\\n\tbin=\"$(readlink -ve /usr/local/bin/python3)\"; \\\n\tdir=\"$(dirname \"$bin\")\"; \\\n\tmkdir -p \"/usr/share/gdb/auto-load/$dir\"; \\\n\tcp -vL Tools/gdb/libpython.py \"/usr/share/gdb/auto-load/$bin-gdb.py\"; \\\n\t\\\n\tcd /; \\\n\trm -rf /usr/src/python; \\\n\t\\\n\tfind /usr/local -depth \\\n\t\t\\( \\\n\t\t\t\\( -type d -a \\( -name test -o -name tests -o -name idle_test \\) \\) \\\n\t\t\t-o \\( -type f -a \\( -name '*.pyc' -o -name '*.pyo' -o -name 'libpython*.a' \\) \\) \\\n\t\t\\) -exec rm -rf '{}' + \\\n\t; \\\n\t\\\n\tldconfig; \\\n\t\\\n\texport PYTHONDONTWRITEBYTECODE=1; \\\n\tpython3 --version; \\\n\tpip3 --version"]

# make some useful symlinks that are expected to exist ("/usr/local/bin/python" and friends)
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tfor src in idle3 pip3 pydoc3 python3 python3-config; do \\\n\t\tdst=\"$(echo \"$src\" | tr -d 3)\"; \\\n\t\t[ -s \"/usr/local/bin/$src\" ]; \\\n\t\t[ ! -e \"/usr/local/bin/$dst\" ]; \\\n\t\tln -svT \"$src\" \"/usr/local/bin/$dst\"; \\\n\tdone"]

CMD ["python3"]
