FROM nginx:1.23

LABEL MAINTAINER="AMIRAJOODANI | https://nextsysadmin.ir"

COPY nginx.conf /etc/nginx/conf.d/default.conf


CMD ["nginx", "-g", "daemon off;"]
