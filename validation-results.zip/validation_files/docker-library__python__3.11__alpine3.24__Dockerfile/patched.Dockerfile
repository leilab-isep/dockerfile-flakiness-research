#
# NOTE: THIS DOCKERFILE IS GENERATED VIA "apply-templates.sh"
#
# PLEASE DO NOT EDIT IT DIRECTLY.
#

FROM alpine:3.24

# ensure local python is preferred over distribution python
ENV PATH /usr/local/bin:$PATH

# cannot remove LANG even though https://bugs.python.org/issue19846 is fixed
# last attempted removal of LANG broke many users:
# https://github.com/docker-library/python/pull/570
ENV LANG C.UTF-8

# runtime dependencies
# TODO(flakiscan): could not automatically fix: DL3018
RUN set -eux; \
	apk add --no-cache \
		ca-certificates \
		tzdata \
	;

ENV GPG_KEY A035C8C19219BA821ECEA86B64E628F8D684696D
ENV PYTHON_VERSION 3.11.16
ENV PYTHON_SHA256 91bcdebfdde239a003ae93738a7fce0f9230fee5c4bc2b86f6e6e8c6f98aabe8

# TODO(flakiscan): could not automatically fix: DL3018, sha256sumEchoOneSpaces
RUN ["/bin/ash", "-o", "pipefail", "-c", "set -eux; \\\n\t\\\n\tapk add --no-cache --virtual .build-deps \\\n\t\tbluez-dev \\\n\t\tbzip2-dev \\\n\t\tdpkg-dev dpkg \\\n\t\tfindutils \\\n\t\tg++ \\\n\t\tgcc \\\n\t\tgdbm-dev \\\n\t\tgnupg \\\n\t\tlibc-dev \\\n\t\tlibffi-dev \\\n\t\tlibnsl-dev \\\n\t\tlibtirpc-dev \\\n\t\tlinux-headers \\\n\t\tmake \\\n\t\tncurses-dev \\\n\t\topenssl-dev \\\n\t\tpax-utils \\\n\t\treadline-dev \\\n\t\tsqlite-dev \\\n\t\ttar \\\n\t\ttcl-dev \\\n\t\ttk \\\n\t\ttk-dev \\\n\t\tutil-linux-dev \\\n\t\txz \\\n\t\txz-dev \\\n\t\tzlib-dev \\\n\t; \\\n\t\\\n\twget -O python.tar.xz \"https://www.python.org/ftp/python/${PYTHON_VERSION%%[a-z]*}/Python-$PYTHON_VERSION.tar.xz\"; \\\n\techo \"$PYTHON_SHA256 *python.tar.xz\" | sha256sum -c -; \\\n\twget -O python.tar.xz.asc \"https://www.python.org/ftp/python/${PYTHON_VERSION%%[a-z]*}/Python-$PYTHON_VERSION.tar.xz.asc\"; \\\n\tGNUPGHOME=\"$(mktemp -d)\"; export GNUPGHOME; \\\n\tgpg --batch --keyserver hkps://keys.openpgp.org --recv-keys \"$GPG_KEY\"; \\\n\tgpg --batch --verify python.tar.xz.asc python.tar.xz; \\\n\tgpgconf --kill all; \\\n\trm -rf \"$GNUPGHOME\" python.tar.xz.asc; \\\n\tmkdir -p /usr/src/python; \\\n\ttar --extract --directory /usr/src/python --strip-components=1 --file python.tar.xz; \\\n\trm python.tar.xz; \\\n\t\\\n\tcd /usr/src/python; \\\n\tgnuArch=\"$(dpkg-architecture --query DEB_BUILD_GNU_TYPE)\"; \\\n\t./configure \\\n\t\t--build=\"$gnuArch\" \\\n\t\t--enable-loadable-sqlite-extensions \\\n\t\t--enable-option-checking=fatal \\\n\t\t--enable-shared \\\n\t\t$(test \"${gnuArch%%-*}\" != 'riscv64' && echo '--with-lto') \\\n\t\t--with-ensurepip \\\n\t; \\\n\tnproc=\"$(nproc)\"; \\\n\tEXTRA_CFLAGS=\"-DTHREAD_STACK_SIZE=0x100000\"; \\\n\tLDFLAGS=\"${LDFLAGS:-} -Wl,--strip-all\"; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-}\" \\\n\t; \\\n\trm python; \\\n\tmake -j \"$nproc\" \\\n\t\t\"EXTRA_CFLAGS=${EXTRA_CFLAGS:-}\" \\\n\t\t\"LDFLAGS=${LDFLAGS:-} -Wl,-rpath='\\$\\$ORIGIN/../lib'\" \\\n\t\tpython \\\n\t; \\\n\tmake install; \\\n\t\\\n\tcd /; \\\n\trm -rf /usr/src/python; \\\n\t\\\n\tfind /usr/local -depth \\\n\t\t\\( \\\n\t\t\t\\( -type d -a \\( -name test -o -name tests -o -name idle_test \\) \\) \\\n\t\t\t-o \\( -type f -a \\( -name '*.pyc' -o -name '*.pyo' -o -name 'libpython*.a' \\) \\) \\\n\t\t\\) -exec rm -rf '{}' + \\\n\t; \\\n\t\\\n\tfind /usr/local -type f -executable -not \\( -name '*tkinter*' \\) -exec scanelf --needed --nobanner --format '%n#p' '{}' ';' \\\n\t\t| tr ',' '\\n' \\\n\t\t| sort -u \\\n\t\t| awk 'system(\"[ -e /usr/local/lib/\" $1 \" ]\") == 0 { next } { print \"so:\" $1 }' \\\n\t\t| xargs -rt apk add --no-network --virtual .python-rundeps \\\n\t; \\\n\tapk del --no-network .build-deps; \\\n\t\\\n\texport PYTHONDONTWRITEBYTECODE=1; \\\n\tpython3 --version; \\\n\t\\\n\tpip3 install \\\n\t\t--disable-pip-version-check \\\n\t\t--no-cache-dir \\\n\t\t--no-compile \\\n\t\t'setuptools==79.0.1' \\\n\t\t'wheel==0.46.3' \\\n\t; \\\n\tpip3 --version"]

# make some useful symlinks that are expected to exist ("/usr/local/bin/python" and friends)
RUN ["/bin/bash", "-o", "pipefail", "-c", "set -eux; \\\n\tfor src in idle3 pip3 pydoc3 python3 python3-config; do \\\n\t\tdst=\"$(echo \"$src\" | tr -d 3)\"; \\\n\t\t[ -s \"/usr/local/bin/$src\" ]; \\\n\t\t[ ! -e \"/usr/local/bin/$dst\" ]; \\\n\t\tln -svT \"$src\" \"/usr/local/bin/$dst\"; \\\n\tdone"]

CMD ["python3"]
