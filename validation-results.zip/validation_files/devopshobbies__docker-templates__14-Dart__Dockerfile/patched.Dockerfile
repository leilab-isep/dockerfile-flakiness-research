# Build stage
FROM dart@sha256:7e57e61d97813dc57dd0801656ff4d5c5efafa47bae563a681571543ad30f199 AS build
WORKDIR /app
COPY pubspec.* /app/
RUN dart pub get --no-precompile
COPY app.dart /app/
RUN dart compile exe app.dart -o app

# Final stage
FROM debian:stable-slim
COPY --from=build /app/app /app/app
CMD ["/app/app"]
