# TODO(flakiscan): could not automatically fix: ruleMoreThanOneInstall
FROM php:8.0-fpm AS build

# Set working directory
WORKDIR /var/www

# Add docker php ext repo
RUN curl -fsSL https://github.com/mlocati/docker-php-extension-installer/releases/latest/download/install-php-extensions -o /usr/local/bin/ && sha256sum /usr/local/bin/

# Install php extensions
RUN chmod +x /usr/local/bin/install-php-extensions && sync && \
    install-php-extensions mbstring pdo_mysql zip exif pcntl gd memcached

# Install dependencies
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y \
    build-essential \
    libpng-dev \
    libjpeg62-turbo-dev \
    libfreetype6-dev \
    locales \
    zip \
    jpegoptim optipng pngquant gifsicle \
    unzip \
    git \
    curl \
    lua-zlib-dev \
    libmemcached-dev \
    nginx \
    nano && rm -rf /var/lib/apt/lists/*

# Install supervisor
# TODO(flakiscan): could not automatically fix: DL3008
RUN apt-get update && apt-get install --no-install-recommends -y supervisor && rm -rf /var/lib/apt/lists/*

# Install composer
# TODO(flakiscan): could not automatically fix: download_no_checksum
RUN ["/bin/bash", "-o", "pipefail", "-c", "curl -L -f -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer"]

# Clear cache
RUN apt-get clean && rm -rf /var/lib/apt/lists/*

# Add user for laravel application
RUN groupadd -g 1000 www && useradd -u 1000 -ms /bin/bash -g www www

# Copy code to /var/www
COPY --chown=www:www-data . /var/www

# add root to www group
RUN chmod -R ug+w /var/www/storage

# Copy nginx/php/supervisor configs
RUN cp docker/supervisor.conf /etc/supervisord.conf
RUN cp docker/php.ini /usr/local/etc/php/conf.d/app.ini
RUN cp docker/nginx.conf /etc/nginx/sites-enabled/default

# PHP Error Log Files
RUN mkdir -p /var/log/php && touch /var/log/php/errors.log && chmod 777 /var/log/php/errors.log


RUN cp docker/.env.production .env
# Deployment steps
RUN composer install --ignore-platform-reqs --optimize-autoloader --no-dev

RUN chmod +x /var/www/docker/run.sh


EXPOSE 80

ENTRYPOINT ["/var/www/docker/run.sh"]





# CMD ["/usr/sbin/nginx", "-g", "daemon off;"]